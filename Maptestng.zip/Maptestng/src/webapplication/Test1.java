package webapplication;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Test1 {
	private static XSSFWorkbook workbook;

	/**
	 * This method is used to launch the browser and open Big Basket Site
	 *
	 */

	@Test
	public void launch() throws Exception {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.bigbasket.com");
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@qa='areaDD']/i")));
		driver.findElement(By.xpath("//a[@qa='areaDD']/i")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//i[@class='caret pull-right'])[1]")));
		driver.findElement(By.xpath("(//i[@class='caret pull-right'])[1]")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='search'])[1]")));
		driver.findElement(By.xpath("(//input[@type='search'])[1]")).sendKeys("hyderabad", Keys.ENTER);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Continue']")));
		// driver.findElement(By.name("area")).sendKeys("500018",Keys.ENTER);

		driver.findElement(By.xpath("//button[text()='Continue']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Shop by Category ']")));
		driver.findElement(By.xpath("//a[text()='Shop by Category ']")).click();
		driver.findElement(By.xpath("(//a[text()='Beverages'])[2]")).click();


		
		WebElement e = driver.findElement(By.id("sel1"));
		Select s = new Select(e);
		s.selectByVisibleText("Price - High to Low");
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h6[@class='ng-binding']")));
		Thread.sleep(5000);

		/*
		 * List<WebElement> actualprice = driver .findElements(By.
		 * xpath("//span[@class='ng-binding' and text()='bbstar Price ']"));
		 * System.out.println(actualprice.size());
		 */
		FileInputStream fis = new FileInputStream("test3.xlsx");
		workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		/*
		 * for(int i=1; i<productname.size(); i++) {
		 * 
		 * Row row1 = sheet.createRow(0); // Creating a row Cell pn =
		 * row1.createCell(0); // Creating a cell pn.setCellValue("Productname"); Cell
		 * sp = row1.createCell(1); // Creating a cell sp.setCellValue("SellingPrice");
		 * 
		 * Cell sp = row1.createCell(1); // Creating a cell
		 * sp.setCellValue("SellingPrice"); Cell ap = row1.createCell(2); // Creating a
		 * cell ap.setCellValue("ActualPrice");
		 * 
		 * System.out.println(productname.get(i).getText());
		 * System.out.println(sellingprice.get(i).getText());
		 * 
		 * //System.out.println(actualprice.get(i).getText());
		 * 
		 * for(int j=0;j<1;j++) {
		 * 
		 * 
		 * Row row=sheet.createRow(i); Cell cell=row.createCell(j);
		 * cell.setCellValue(productname.get(i).getText()); Cell
		 * cell1=row.createCell(j+1); cell1.setCellValue(sellingprice.get(i).getText());
		 * 
		 * 
		 * 
		 * //Cell cell2=row.createCell(j+2);
		 * //cell2.setCellValue(actualprice.get(i).getText());
		 * 
		 * 
		 * }
		 */

		List<WebElement> AllProd = driver.findElements(By.xpath("//*[@qa='product_name']"));
		Thread.sleep(20000);
		System.out.println(AllProd.size());
		for (int i = 1; i < AllProd.size(); i++) {
			List<WebElement> productname = driver.findElements(By.xpath("//*[@qa='product_name']"));
			Row FirstRow = sheet.createRow(0); // Creating a row
			Cell ProductName = FirstRow.createCell(0); // Creating a cell
			ProductName.setCellValue("Productname");
			Cell CutOverPrice = FirstRow.createCell(1); // Creating a cell
			CutOverPrice.setCellValue("Displayed Price");
			Cell DisplatedPrice = FirstRow.createCell(2); // Creating a cell
			DisplatedPrice.setCellValue("CutOver Price");
			Row row = sheet.createRow(i);
			List<WebElement> price = driver.findElements(By.xpath("(//*[@qa='price'])[" + i + "]/descendant::h4/span"));

			if (price.size() == 1) {

				Cell Product = row.createCell(0);
				Product.setCellValue(productname.get(i).getText());
				WebElement DSP = driver
						.findElement(By.xpath("(//*[@qa='price'])[" + i + "]/descendant::h4/span/span[2]"));
				System.out.println("Displayed Price is :" + DSP.getText());
				Cell DSPE = row.createCell(1);
				DSPE.setCellValue(DSP.getText());
			}

			if (price.size() == 2) {
				Cell Product = row.createCell(0);
				Product.setCellValue(productname.get(i).getText());
				WebElement DSP = driver
						.findElement(By.xpath("(//*[@qa='price'])[" + i + "]/descendant::h4/span[2]/span"));
				System.out.println("Displayed Price is : " + DSP.getText());
				Cell DSPE = row.createCell(1);
				DSPE.setCellValue(DSP.getText());
				WebElement COP = driver
						.findElement(By.xpath("(//*[@qa='price'])[" + i + "]/descendant::h4/span[1]/span"));
				System.out.println("CutOver Price is : " + COP.getText());
				Cell COPE = row.createCell(2);
				COPE.setCellValue(COP.getText());

			}

		}

		for (int i = 0; i < AllProd.size(); i++) {
			long start = System.currentTimeMillis();
			List<WebElement> productname = driver.findElements(By.xpath("//*[@qa='product_name']"));
			productname.get(i).click();
			WebElement AddBask = driver.findElement(By.xpath("//*[text()='ADD TO BASKET']"));
			wait.until(ExpectedConditions.visibilityOf(AddBask));
			driver.navigate().back();
			long finish = System.currentTimeMillis();
			long totalTime = finish - start;
			System.out.println("Total Time take to navigate to Product in milli seconds is : " + totalTime);
			Thread.sleep(2000);
		}
		

		FileOutputStream fos = new FileOutputStream("test3.xlsx");
		workbook.write(fos);
		fos.close();
		driver.close();

	}

}
